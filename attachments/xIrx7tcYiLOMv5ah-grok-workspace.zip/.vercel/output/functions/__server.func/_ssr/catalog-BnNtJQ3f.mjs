import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button, o as productOrderMessage, s as waLink } from "./router-DCG1DHCc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-BnNtJQ3f.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col overflow-hidden rounded-2xl bg-surface shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-[4/3] overflow-hidden bg-surface-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: product.image,
				alt: product.imageAlt,
				className: "size-full object-cover transition-transform duration-300 ease-out hover:scale-[1.03]"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-3 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.65rem] font-medium uppercase tracking-[0.18em] text-muted",
						children: product.category
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-2xl font-medium",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: product.blurb
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: "Price on request"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "whatsapp",
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: waLink(productOrderMessage(product.name)),
						target: "_blank",
						rel: "noreferrer",
						children: "Order"
					})
				})]
			})]
		})]
	});
}
var CATEGORIES = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "cakes",
		label: "Cakes"
	},
	{
		id: "snacks",
		label: "Snacks"
	},
	{
		id: "bags",
		label: "Bags"
	}
];
var PRODUCTS = [
	{
		id: "chocolate-drip",
		name: "Chocolate Drip Cake",
		category: "cakes",
		blurb: "Dark chocolate layers with ganache drip and berries. A favourite for birthdays.",
		image: "/images/cake-chocolate.jpg",
		imageAlt: "Chocolate drip cake with strawberries"
	},
	{
		id: "rainbow-birthday",
		name: "Rainbow Birthday Cake",
		category: "cakes",
		blurb: "Bright, colourful celebration cake for kids and big kids. Custom colours and names available.",
		image: "/images/cake-birthday.jpg",
		imageAlt: "Colourful layered birthday cake with sprinkles"
	},
	{
		id: "berry-naked",
		name: "Berry Naked Cake",
		category: "cakes",
		blurb: "Rustic cream cake stacked with fresh berries. Perfect for small parties and photos.",
		image: "/images/cake-naked.jpg",
		imageAlt: "Naked cream cake topped with mixed berries"
	},
	{
		id: "blush-rose-cake",
		name: "Blush Rose Celebration Cake",
		category: "cakes",
		blurb: "Two-tier buttercream with a silk bow and sugar roses for engagements and milestones.",
		image: "/images/cake-blush.jpg",
		imageAlt: "Two-tier blush celebration cake with a silk bow"
	},
	{
		id: "pearl-garden-cake",
		name: "Pearl Garden Cake",
		category: "cakes",
		blurb: "Floral wedding-style cake with pearl piping. Quote by size and filling.",
		image: "/images/cake-pearl.jpg",
		imageAlt: "White and blush floral celebration cake"
	},
	{
		id: "floral-cupcakes",
		name: "Floral Cupcake Box",
		category: "snacks",
		blurb: "A dozen pastel cupcakes with edible flowers. Great as table treats or gifts.",
		image: "/images/cupcakes.jpg",
		imageAlt: "Tray of pastel floral cupcakes"
	},
	{
		id: "golden-chinchin",
		name: "Golden Chin Chin",
		category: "snacks",
		blurb: "Crisp small-batch chin chin. Order by the pack for events or the house.",
		image: "/images/chinchin.jpg",
		imageAlt: "Bowl of homemade chin chin"
	},
	{
		id: "glazed-rings",
		name: "Glazed Snack Rings",
		category: "snacks",
		blurb: "Soft glazed rings for parties and office packs. Mix flavours on request.",
		image: "/images/snacks-donuts.jpg",
		imageAlt: "Glazed snack rings on a cooling rack"
	},
	{
		id: "cinnamon-buns",
		name: "Cinnamon Buns",
		category: "snacks",
		blurb: "Warm, sticky buns for brunch tables and gift boxes.",
		image: "/images/snacks-pastry.jpg",
		imageAlt: "Fresh cinnamon buns in a baking pan"
	},
	{
		id: "cookie-box",
		name: "Cookie Box",
		category: "snacks",
		blurb: "Chewy chocolate-chip cookies packed for sharing. Custom boxes available.",
		image: "/images/snacks-cookies.jpg",
		imageAlt: "Chocolate chip cookies stacked on a plate"
	},
	{
		id: "blush-quilted-mini",
		name: "Blush Quilted Mini",
		category: "bags",
		blurb: "Structured mini bag with quilted body and bow. Handmade styles available.",
		image: "/images/bag-mini.jpg",
		imageAlt: "Blush quilted mini handbag"
	},
	{
		id: "cream-bow-bag",
		name: "Cream Bow Handbag",
		category: "bags",
		blurb: "Soft cream bag with chain strap. Dressy enough for events, easy for daily use.",
		image: "/images/bag-cream.jpg",
		imageAlt: "Cream structured handbag with gold chain"
	},
	{
		id: "noir-classic",
		name: "Noir Classic Bag",
		category: "bags",
		blurb: "Black imported-style bag with gold hardware. A go-with-everything piece.",
		image: "/images/bag-black.jpg",
		imageAlt: "Black leather handbag with gold clasp"
	},
	{
		id: "sun-tote",
		name: "Sun Tote",
		category: "bags",
		blurb: "Bold yellow tote for market days and weekends. Handmade and imported options.",
		image: "/images/bag-yellow.jpg",
		imageAlt: "Yellow tote bag with a woman walking in sunlight"
	},
	{
		id: "camel-work-bag",
		name: "Camel Work Bag",
		category: "bags",
		blurb: "Tan structured bag for office and travel. Ask for current imported stock.",
		image: "/images/bag-brown.jpg",
		imageAlt: "Tan brown leather work bag"
	}
];
var FEATURED_IDS = [
	"chocolate-drip",
	"sun-tote",
	"rainbow-birthday",
	"noir-classic",
	"golden-chinchin",
	"berry-naked"
];
function featuredProducts() {
	return FEATURED_IDS.map((id) => PRODUCTS.find((p) => p.id === id)).filter((p) => Boolean(p));
}
function productsByCategory(category) {
	if (category === "all") return PRODUCTS;
	return PRODUCTS.filter((p) => p.category === category);
}
//#endregion
export { productsByCategory as i, ProductCard as n, featuredProducts as r, CATEGORIES as t };
