//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B60-rlAw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/gallery"
		],
		preloads: ["/assets/index-BQaFhp4M.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BQaFhp4M.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BNWfpIWg.js",
			"/assets/message-form-ByKUR9kZ.js",
			"/assets/catalog-BMd1-6O7.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DzSlfZDw.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-pcYj-FuD.js", "/assets/message-form-ByKUR9kZ.js"]
	},
	"/gallery": {
		filePath: "/workspace/src/routes/gallery.tsx",
		children: void 0,
		preloads: ["/assets/gallery-BjyhxRQ7.js", "/assets/catalog-BMd1-6O7.js"]
	}
} });
//#endregion
export { tsrStartManifest };
