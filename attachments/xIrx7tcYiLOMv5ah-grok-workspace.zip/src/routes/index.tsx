import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CakeSlice, MessageCircle, ShoppingBag, Sparkles } from "lucide-react";
import { MessageForm } from "@/components/message-form";
import { ProductCard } from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { featuredProducts } from "@/lib/catalog";
import { DEFAULT_ORDER_MESSAGE, SITE, waLink } from "@/lib/site";

export const Route = createFileRoute("/")({ component: Home });

const STEPS = [
  {
    n: "01",
    title: "See the work",
    body: "Scroll the gallery. Cakes, snacks, and bags are all different pieces. Pick a style close to what you want.",
  },
  {
    n: "02",
    title: "Start a message",
    body: "Use the form on this page. Write the date, colours, size, or bag style. WhatsApp opens with your words ready.",
  },
  {
    n: "03",
    title: "Get a quote",
    body: "Prices change with design and timing. DUPZY Cakes N' Bags replies with availability, then you confirm and pay as agreed.",
  },
];

const SERVICES = [
  {
    icon: CakeSlice,
    title: "Cakes",
    body: "Birthday, wedding, engagement, and corporate cakes. Fillings, tiers, and colours are custom.",
  },
  {
    icon: Sparkles,
    title: "Snacks",
    body: "Chin chin, cupcakes, buns, cookie boxes, and party packs for small gatherings or events.",
  },
  {
    icon: ShoppingBag,
    title: "Bags",
    body: "Handmade pieces and imported styles: minis, totes, work bags, and classic black bags.",
  },
];

const FAQS = [
  {
    q: "Do you have fixed prices?",
    a: "No. Size, design, ingredients, and bag style change the price. Message first and you will get a quote.",
  },
  {
    q: "How far ahead should I order a cake?",
    a: "As soon as you know the date. Busy weekends fill up. Same-week orders are possible when the diary is free.",
  },
  {
    q: "Do you deliver?",
    a: "Ask in your message with your area. Pickup and delivery options depend on the order and location.",
  },
  {
    q: "Are the bags handmade or imported?",
    a: "Both. Say which you prefer. Stock of imported styles changes, so WhatsApp is the fastest way to check.",
  },
];

function Home() {
  const featured = featuredProducts();

  return (
    <div>
      <section className="bg-bg">
        <div className="mx-auto flex max-w-5xl flex-col items-center px-4 pb-14 pt-6 text-center sm:px-6 sm:pb-20 sm:pt-8">
          <img
            src="/images/logo.jpg"
            alt={SITE.name}
            className="mark w-full max-w-3xl object-contain"
          />
          <h1 className="mt-1 font-display text-4xl font-semibold text-fg sm:text-6xl">
            {SITE.name}
          </h1>
          <p className="mt-3 max-w-3xl font-display text-2xl italic text-fg/80 sm:text-3xl">
            {SITE.tagline}
          </p>
          <p className="mt-5 max-w-2xl text-base text-fg/80 sm:text-lg">{SITE.together}</p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button variant="whatsapp" size="lg" asChild>
              <a href="#message">Start a message</a>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link to="/gallery">
                Browse gallery
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-surface">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
          <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">The idea</p>
          <h2 className="mt-2 max-w-3xl font-display text-4xl">Why cakes and bags share one name</h2>
          <p className="mt-4 max-w-3xl text-base text-muted">
            A celebration has a table and an outfit. DUPZY is built for both: the cake that marks
            the day, and the bag you carry after the candles are out. You do not need two vendors
            or two chats. Message once. Ask for either, or both.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">What we make</p>
        <h2 className="mt-2 font-display text-4xl">One studio, three shelves</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {SERVICES.map((s) => (
            <article key={s.title} className="rounded-2xl bg-surface p-6 shadow-border">
              <s.icon className="size-6 text-accent" />
              <h3 className="mt-4 font-display text-2xl">{s.title}</h3>
              <p className="mt-2 text-sm text-muted">{s.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-surface">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
          <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">How to order</p>
          <h2 className="mt-2 font-display text-4xl">From this page to WhatsApp</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {STEPS.map((step) => (
              <article key={step.n}>
                <p className="font-display text-3xl text-accent">{step.n}</p>
                <h3 className="mt-2 font-display text-2xl">{step.title}</h3>
                <p className="mt-2 text-sm text-muted">{step.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">
              Different pieces
            </p>
            <h2 className="mt-2 font-display text-4xl">Cakes, snacks, and bags</h2>
          </div>
          <Link to="/gallery" className="text-sm font-medium text-fg underline-offset-4 hover:underline">
            Full gallery
          </Link>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="bg-fg text-bg">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-primary">
              Write first
            </p>
            <h2 className="mt-2 font-display text-4xl text-bg">Start the conversation here</h2>
            <p className="mt-4 max-w-md text-bg/75">
              This is the message box. Choose a cake, a bag, or both. Type the details and send.
              It opens WhatsApp so DUPZY Cakes N' Bags can reply with a price.
            </p>
            <Button variant="whatsapp" size="lg" className="mt-6" asChild>
              <a href={waLink(DEFAULT_ORDER_MESSAGE)} target="_blank" rel="noreferrer">
                <MessageCircle className="size-4" />
                Or open a blank chat
              </a>
            </Button>
          </div>
          <MessageForm />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">Questions</p>
        <h2 className="mt-2 font-display text-4xl">Before you message</h2>
        <div className="mt-8 divide-y divide-border rounded-2xl bg-surface shadow-border">
          {FAQS.map((item) => (
            <details key={item.q} className="group px-5 py-4">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium">
                {item.q}
                <span className="text-muted group-open:hidden">+</span>
                <span className="hidden text-muted group-open:inline">−</span>
              </summary>
              <p className="mt-2 max-w-2xl text-sm text-muted">{item.a}</p>
            </details>
          ))}
        </div>
      </section>
    </div>
  );
}
