import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ProductCard } from "@/components/product-card";
import { CATEGORIES, productsByCategory, type Category } from "@/lib/catalog";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/gallery")({ component: GalleryPage });

function GalleryPage() {
  const [filter, setFilter] = useState<Category | "all">("all");
  const items = productsByCategory(filter);

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">Portfolio</p>
      <h1 className="mt-2 font-display text-5xl">Gallery</h1>
      <p className="mt-3 max-w-xl text-muted">
        Cakes, snacks, and bags. Each photo is a different piece. Filter, then tap
        Order to start a WhatsApp message with that item named.
      </p>

      <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="Filter gallery">
        {CATEGORIES.map((cat) => {
          const active = filter === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setFilter(cat.id)}
              className={cn(
                "h-11 rounded-full px-4 text-sm font-medium transition-colors duration-150",
                active
                  ? "bg-primary text-primary-fg"
                  : "bg-surface text-fg shadow-border hover:bg-surface-muted",
              )}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
