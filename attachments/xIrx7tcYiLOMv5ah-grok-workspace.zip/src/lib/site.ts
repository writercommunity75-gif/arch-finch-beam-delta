export const SITE = {
  name: "DUPZY Cakes N' Bags",
  shortName: "DUPZY",
  tagline: "The cake for the day. The bag for every day.",
  together:
    "Celebrations need a cake. Everyday life needs a bag you actually carry. DUPZY Cakes N' Bags keeps both in one studio so you can order the party and the piece in the same WhatsApp chat.",
  owner: "Oladosu Modupeoluwa Christiana",
  email: "oladosumodupeoluwa@gmail.com",
  phoneDisplay: "+234 904 252 3122",
  whatsappE164: "2349042523122",
  city: "Nigeria",
} as const;

export function waLink(message?: string) {
  const base = `https://wa.me/${SITE.whatsappE164}`;
  if (!message) return base;
  return `${base}?text=${encodeURIComponent(message)}`;
}

export const DEFAULT_ORDER_MESSAGE =
  "Hello DUPZY Cakes N' Bags, I would like to place an order.";

export function productOrderMessage(name: string) {
  return `Hello DUPZY Cakes N' Bags, I am interested in the ${name}. Please share availability and price.`;
}
